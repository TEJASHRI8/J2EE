package com.app.pojos;

public enum Role {
	VENDOR, ADMIN
}
