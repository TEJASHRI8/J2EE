package com.app.dao;

import com.app.pojos.Vendor;

public interface IBankAccountDao {
	String createAccount(Vendor v);
}
